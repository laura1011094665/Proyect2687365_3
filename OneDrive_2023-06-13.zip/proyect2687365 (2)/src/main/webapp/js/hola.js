const menuButton = document.getElementById('menu-button');
const sidebar = document.getElementById('sidebar');

menuButton.addEventListener('click', () => {
    sidebar.style.right = '0';
});

document.addEventListener('click', (event) => {
    const target = event.target;
    const isMenuButton = target === menuButton || menuButton.contains(target);
    const isSidebar = target === sidebar || sidebar.contains(target);

    if (!isMenuButton && !isSidebar) {
        sidebar.style.right = '-250px';
    }
});
